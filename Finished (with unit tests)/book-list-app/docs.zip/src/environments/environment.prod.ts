export const environment = {
  production: true,
  API_REST_URL: 'http://localhost:55599',
};
